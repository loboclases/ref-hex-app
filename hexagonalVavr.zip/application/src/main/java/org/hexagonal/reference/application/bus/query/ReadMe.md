Interfaces in this package should be put in a shared kernel jar so it is reusable in all the bounded context

However, due to didactic purposes, it is put as a separate package in the application layer 