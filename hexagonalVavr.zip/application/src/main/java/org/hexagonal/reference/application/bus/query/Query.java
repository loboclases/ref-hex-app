package org.hexagonal.reference.application.bus.query;

/**
 * Marqker interface for Queries.
 *
 *
 * @author joseluis.anton
 */
public interface Query {

}
