package org.hexagonal.reference.application.bus.command;

/**
 * Marqker interface for Commands.
 * @author joseluis.anton
 */
public interface Command {

}
