package org.hexagonal.reference.infrastructure.adapter.driving;

import io.vavr.control.Either;
import io.vavr.control.Validation;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.hexagonal.reference.application.usecase.CreateUserUseCase;
import org.hexagonal.reference.application.usecase.FindUserUseCase;
import org.hexagonal.reference.application.usecase.command.CreateUserCommand;
import org.hexagonal.reference.application.usecase.dto.UserDTO;
import org.hexagonal.reference.application.usecase.query.GetUserQueryById;
import org.hexagonal.reference.application.usecase.query.GetUserQueryByName;
import org.hexagonal.reference.domain.model.User;
import org.hexagonal.reference.domain.model.error.GeneralError;
import org.hexagonal.reference.domain.model.error.ValidationError;
import org.hexagonal.reference.infrastructure.adapter.model.UserResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * The type User rest adapter.
 */
@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
public class UserRestAdapter {

  private final FindUserUseCase findUserUseCase;
  private final CreateUserUseCase createUserUseCase;

  @GetMapping("/{id}")
  public ResponseEntity<?> findUserById(@PathVariable("id") Long id) {
    Validation<List<ValidationError>, GetUserQueryById> query = GetUserQueryById.validateAndCreate(
        id);
    ResponseEntity<?> responseEntity;
    if (!query.isValid()) {
      responseEntity = ResponseEntity.badRequest().body(query.getError());
    } else {
      Either<List<GeneralError>, UserDTO> operation = findUserUseCase.findUserById(query.get());
      if (operation.isLeft()) {
        responseEntity = ResponseEntity.status(HttpStatus.I_AM_A_TEAPOT).body(operation.getLeft());
      } else {
        responseEntity = ResponseEntity.ok(
            UserResource.builder().age(operation.get().getAge())
                .name(operation.get().getName()).email(operation.get().getEmail()).id(operation.get().getId())
                .build());
      }
    }
    return responseEntity;
  }
  @GetMapping("")
  public ResponseEntity<?> findUserByName(@RequestParam("name") String name) {
    Validation<List<ValidationError>, GetUserQueryByName> query = GetUserQueryByName.validateAndCreate(
        name);
    ResponseEntity<?> responseEntity;
    if (!query.isValid()) {
      responseEntity = ResponseEntity.badRequest().body(query.getError());
    } else {
      Either<List<GeneralError>, Optional<UserDTO>> operation = findUserUseCase.findUserByName(query.get());
      if (operation.isLeft()) {
        responseEntity = ResponseEntity.status(HttpStatus.I_AM_A_TEAPOT).body(query.getError());
      } else {
        UserResource dto=operation.get().map(user-> UserResource.builder().age(user.getAge())
            .name(user.getName()).email(user.getEmail()).id(user.getId())
            .build()).orElse(null);
        responseEntity = ResponseEntity.ok(
            dto);
      }
    }
    return responseEntity;
  }
  @PostMapping("/")
  public ResponseEntity<?> createUser(@RequestBody UserResource userResource){
    Validation<List<ValidationError>, CreateUserCommand> command=CreateUserCommand.validateAndCreate(
        userResource.getName(),
        userResource.getAge(), userResource.getEmail());
    ResponseEntity<?> responseEntity;
    if (!command.isValid()) {
      responseEntity = ResponseEntity.badRequest().body(command.getError());
    } else {
      Either<List<GeneralError>, UserDTO>operation=this.createUserUseCase.createUser(command.get());
      if (operation.isLeft()) {
        responseEntity = ResponseEntity.status(HttpStatus.I_AM_A_TEAPOT).body(operation.getLeft());
      } else {
        responseEntity = ResponseEntity.ok(
            UserResource.builder().age(operation.get().getAge())
                .name(operation.get().getName()).email(operation.get().getEmail()).id(operation.get().getId())
                .build());
      }
    }
    return responseEntity;
  }

}
