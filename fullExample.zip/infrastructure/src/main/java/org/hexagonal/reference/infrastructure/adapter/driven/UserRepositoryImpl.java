package org.hexagonal.reference.infrastructure.adapter.driven;

import static io.vavr.API.$;
import static io.vavr.API.Match;

import io.vavr.control.Either;
import io.vavr.control.Try;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hexagonal.reference.domain.factory.UserFactory;
import org.hexagonal.reference.domain.model.error.GeneralError;
import org.hexagonal.reference.domain.model.error.TechnicalError;
import org.hexagonal.reference.domain.model.User;
import org.hexagonal.reference.domain.model.error.UserNotFound;
import org.hexagonal.reference.domain.port.driven.UserRepository;
import org.hexagonal.reference.infrastructure.persistence.model.UserEntity;
import org.hexagonal.reference.infrastructure.persistence.repository.PostgresUserRepository;
import org.springframework.stereotype.Repository;


/**
 * The type User repository.
 */
@Repository
@RequiredArgsConstructor
@Slf4j
public class UserRepositoryImpl implements UserRepository {

  private final UserFactory userFactory;
  private final PostgresUserRepository userRepository;

  @Override
  public Either<List<GeneralError>, Optional<User>> findByUsername(String username) {
    Either<List<GeneralError>, Optional<UserEntity>> findOperation = Try.of(() -> userRepository.findByName(username)).onFailure(e -> log.error(
            "Could not find user with id %s due to some error %s".formatted(username, e.getMessage())))
        .toEither()
        .<List<GeneralError>>mapLeft(exception -> Arrays.asList(new TechnicalError(
            "Error searching user with id %s due to error &s".formatted(username, exception.getMessage()),
            exception))
        ).map(user -> Optional.ofNullable(user));
    Either<List<GeneralError>, Optional<User>> result = null;
    if (findOperation.isLeft()) { //technical error searching for the user
      result = Either.left(findOperation.getLeft());
    } else {
      Optional<UserEntity> foundUser = findOperation.get();
      if (foundUser.isEmpty()) {//there was no error, the user just does not exist
        result = Either.right(Optional.empty());
      } else {//the user does exist, mapping back to User business entity
        UserEntity entity=foundUser.get();
        result = Either.right(Optional.of(
            userFactory.createUser(entity.getName(), entity.getEmail(), entity.getAge(),entity.getId())
                .get()));
      }

    }
    return result;
  }

  /**
   *
   * {@inheritDoc}
   */
  @Override
  public Either<List<GeneralError>, User> saveUser(User user) {
    UserEntity entity = new UserEntity();
    entity.setAge(user.getAge().getValue());
    entity.setName(user.getUserName());
    entity.setEmail(user.getEmail().getValue());
    return Try.of(() -> userRepository.save(entity))
        .toEither()
        .<List<GeneralError>>mapLeft(exception -> Arrays.asList(new TechnicalError(
            "Error saving user %s due to error %s".formatted(user, exception.getMessage()),
            exception))
        ).map(savedUser -> userFactory.createUser(savedUser.getName(), savedUser.getEmail(),
            savedUser.getAge(),savedUser.getId()).get());
  }
  /**
   *
   * {@inheritDoc}
   */
  @Override
  public Either<List<GeneralError>, Void> deleteUser(String username) {
    Either<List<GeneralError>, Void> result = null;
    Either<List<GeneralError>, UserEntity> findOperation = Try.of(
        () -> userRepository.findByName(username))
        .onFailure(e -> log.error(
            "Could not find user with name %s due to some error %s".formatted(username, e.getMessage())))
        .toEither().<List<GeneralError>>mapLeft(
        exception -> Arrays.asList(
            new TechnicalError("Error, user with name %s not found".formatted(username),
                exception)));
    if (findOperation.isLeft()) {//technical error searching for the user
      result = Either.left(findOperation.getLeft());
    } else {
      if(null==findOperation.get()){//there was no error, the user just does not exist
        result = Either.left(Arrays.asList(new UserNotFound("User with id %s not found".formatted(username))));
      }else {//user found, trying to delete it
        UserEntity entity = findOperation.get();
        result = Try.run(() -> userRepository.delete(entity)).onFailure(e -> log.error(
                "Could not delete user with name %s due to some error %s".formatted(username,
                    e.getMessage())))
            .toEither().<List<GeneralError>>mapLeft(
                exception -> Arrays.asList(
                    new TechnicalError("Error, user with name %s not found".formatted(username),
                        exception)));
      }
    }
    return result;
  }
  /**
   *
   * {@inheritDoc}
   */
  @Override
  public Either<List<GeneralError>, User> findById(Long id) {
    Either<List<GeneralError>, UserEntity> findOperation = Try.of(() -> userRepository.findById(id)).onFailure(e -> log.error(
            "Could not find user with id %s due to some error %s".formatted(id, e.getMessage())))
        .toEither()
        .<List<GeneralError>>mapLeft(exception -> Arrays.asList(new TechnicalError(
            "Error searching user with id %s due to error &s".formatted(id, exception.getMessage()),
            exception))
        ).map(user -> user.orElse(null));
    Either<List<GeneralError>, User> result = null;
    if (findOperation.isLeft()) { //technical error searching for the user
      result = Either.left(findOperation.getLeft());
    } else {
      UserEntity foundUser = findOperation.get();
      if (null == foundUser) {//there was no error, the user just does not exist
        result = Either.left(
            Arrays.asList(new UserNotFound("user with id %s not found".formatted(id))));
      } else {//the user does exist, mapping back to User business entity
        result = Either.right(
            userFactory.createUser(foundUser.getName(), foundUser.getEmail(), foundUser.getAge(),foundUser.getId())
                .get());
      }

    }
    return result;
  }
}
