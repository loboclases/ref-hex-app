package org.hexagonal.reference.application;

import io.vavr.control.Either;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hexagonal.reference.application.usecase.CreateUserUseCase;
import org.hexagonal.reference.application.usecase.FindUserUseCase;
import org.hexagonal.reference.application.usecase.command.CreateUserCommand;
import org.hexagonal.reference.application.usecase.dto.UserDTO;
import org.hexagonal.reference.application.usecase.query.GetUserQueryById;
import org.hexagonal.reference.application.usecase.query.GetUserQueryByName;
import org.hexagonal.reference.domain.factory.UserFactory;
import org.hexagonal.reference.domain.model.User;
import org.hexagonal.reference.domain.model.error.GeneralError;
import org.hexagonal.reference.domain.model.error.ValidationError;
import org.hexagonal.reference.domain.port.driven.UseCase;
import org.hexagonal.reference.domain.port.driven.UserRepository;

@RequiredArgsConstructor
@Slf4j
public class ApplicationService implements CreateUserUseCase, FindUserUseCase {

  private final UserFactory userFactory;
  private final UserRepository userRepository;

  /**
   * {@inheritDoc}
   */
  @Override
  @UseCase
  public Either<List<GeneralError>, UserDTO> createUser(CreateUserCommand createUserCommand) {
    Either<List<GeneralError>, UserDTO> result;
    Either<List<ValidationError>, User> user = userFactory.createUser(
        createUserCommand.getUsername(), createUserCommand.getEmail(), createUserCommand.getAge(),0l);
    if (user.isRight()) {//if all validations are ok, domain layer can be invoke
      result = userRepository.saveUser(user.get()).map(savedUser->mapToDto(savedUser));
    } else {
      List<GeneralError> errors = new ArrayList<>();
      errors.addAll(user.getLeft());
      result = Either.left(errors);
    }
    return result;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @UseCase
  public Either<List<GeneralError>, Optional<UserDTO>> findUserByName(
      GetUserQueryByName getUserQuery) {
    return userRepository.findByUsername(getUserQuery.getName())
        .map(optUser -> optUser.map(user -> mapToDto(user))
        );
  }

  /**
   * {@inheritDoc}
   */
  @Override
  @UseCase
  public Either<List<GeneralError>, UserDTO> findUserById(GetUserQueryById getUserQuery) {
    return userRepository.findById(getUserQuery.getId()).map(user->mapToDto(user));
  }

  private UserDTO mapToDto(User user) {
    return UserDTO.builder().name(user.getUserName()).id(user.getId().getValue())
        .age(user.getAge().getValue()).email(user.getEmail().getValue()).build();
  }
}
