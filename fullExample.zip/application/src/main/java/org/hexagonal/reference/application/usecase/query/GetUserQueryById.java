package org.hexagonal.reference.application.usecase.query;

import io.vavr.control.Validation;
import java.util.Arrays;
import java.util.List;
import lombok.AccessLevel;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.hexagonal.reference.domain.specification.PositiveNumber;
import org.hexagonal.reference.domain.model.error.ValidationError;

/**
 * The type Get user query.
 */
@Data
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class GetUserQueryById {

  private final Long id;

  /**
   * Validate and create validation.
   *
   * @param id the id
   * @return the validation
   */
  public static Validation<List<ValidationError>, GetUserQueryById> validateAndCreate(
       final Long id) {
    return new PositiveNumber().isSatisfiedBy(id) ? Validation.valid(new GetUserQueryById(id))
        : Validation.invalid(Arrays.asList(new ValidationError("Error, id %s not valid".formatted(id))));
  }

}
