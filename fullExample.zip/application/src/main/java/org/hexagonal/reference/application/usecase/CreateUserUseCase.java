package org.hexagonal.reference.application.usecase;


import io.vavr.control.Either;
import java.util.List;
import org.hexagonal.reference.application.usecase.command.CreateUserCommand;
import org.hexagonal.reference.application.usecase.dto.UserDTO;
import org.hexagonal.reference.domain.model.User;
import org.hexagonal.reference.domain.model.error.GeneralError;

/**
 * The interface Create user use case.
 */
public interface CreateUserUseCase {

  /**
   * Create user either.
   *
   * @param createUserCommand the create user command
   * @return the either
   */
  Either<List<GeneralError>, UserDTO> createUser(CreateUserCommand createUserCommand);
}
