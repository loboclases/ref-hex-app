package org.hexagonal.reference.domain.model.error;

import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * The type Validation error.
 */
public record ValidationError(String msg) implements GeneralError {

}
