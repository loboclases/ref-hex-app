package org.hexagonal.reference.domain.model.error;

public record UserNotFound(String msg) implements GeneralError {

}
