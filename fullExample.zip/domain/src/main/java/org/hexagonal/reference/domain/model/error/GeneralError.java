package org.hexagonal.reference.domain.model.error;

public sealed interface GeneralError permits UserNotFound, TechnicalError,ValidationError {
}

