package org.hexagonal.reference.domain.model.error;

public record TechnicalError(String msg, Throwable exception) implements GeneralError {

}
