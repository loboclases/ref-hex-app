package org.hexagonal.reference.domain.port.driven;

import io.vavr.control.Either;
import java.util.List;
import java.util.Optional;
import org.hexagonal.reference.domain.model.error.GeneralError;
import org.hexagonal.reference.domain.model.User;

/**
 * The interface User repository.
 */
public interface UserRepository {

  /**
   * Find by username try.
   *
   * @param username the username
   * @return the try
   */
  Either<List<GeneralError>, Optional<User>> findByUsername(String username);

  /**
   * Save user try.
   *
   * @param user the user
   * @return the try
   */
  Either<List<GeneralError>,User> saveUser(User user);

  /**
   * Delete user try.
   *
   * @param username the username
   * @return the try
   */
  Either<List<GeneralError>,Void> deleteUser(String username);

  /**
   * Find by id try.
   *
   * @param id the id
   * @return the try
   */
  Either<List<GeneralError>,User> findById(Long id);


}
